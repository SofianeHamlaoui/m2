---
name: Assignment Question
about: Template used for asking questions regarding an assignment

---

## Assignment number: 

## Question:

## Version of imported packages
* Python: 
* ...
